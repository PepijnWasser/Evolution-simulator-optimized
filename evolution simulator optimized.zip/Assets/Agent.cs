﻿using UnityEngine;

public class Agent
{
    public float waterGatherPercentage;
    public int lifeTime;

    private int _foodStored;
    private int _waterStored;

    private int _foodUsed;
    private int _waterUsed;

    private int _foodGathered;
    private int _waterGathered;

    private int _timesWaterChosen = 1;
    private int _timesFoodChosen = 1;

    public Agent(AgentController _agentController, Agent _parent = null)
    {
        bool _hasParent;
        if (_parent == null)
        {
            _hasParent = false;
        }
        else
        {
            _hasParent = true;
        }

        switch (_hasParent)
        {
            case false:
                SetWorldVariables(_agentController);
                waterGatherPercentage = _agentController.startPercentage;

                break;

            case true:
                SetWorldVariables(_agentController);
                waterGatherPercentage = _parent.waterGatherPercentage + Random.Range(-0.5f, 0.5f);
                waterGatherPercentage = Mathf.Clamp(waterGatherPercentage, 0, 100);

                break;
        }
    }

    private void SetWorldVariables(AgentController agentController)
    {
        _foodStored = agentController.startFood;
        _waterStored = agentController.startWater;

        _foodUsed = agentController.foodUsed;
        _waterUsed = agentController.waterUsed;

        _foodGathered = agentController.foodGathered;
        _waterGathered = agentController.waterGathered;
    }

    public void StartNewDay()
    {
        GatherSupllies();
        TestSurvival();
    }

    private void GatherSupllies()
    {
        float _waterChosenPercentage = ((float)_timesWaterChosen / (_timesWaterChosen + _timesFoodChosen)) * 100.0f;
        if (_waterChosenPercentage < waterGatherPercentage)
        {
            _timesWaterChosen += 1;
            _waterStored += _waterGathered;
        }
        else
        {
            _timesFoodChosen += 1;
            _foodStored += _foodGathered;
        }
    }

    private void TestSurvival()
    {
        if ((_foodStored - _foodUsed >= 0) && (_waterStored - _waterUsed >= 0))
        {
            _foodStored -= _foodUsed;
            _waterStored -= _waterUsed;
            lifeTime += 1;
            if (lifeTime < 5000)
            {
                StartNewDay();
            }
        }
    }
}
