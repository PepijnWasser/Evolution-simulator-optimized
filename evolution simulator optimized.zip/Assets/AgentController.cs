﻿using System.Linq;
using UnityEngine;
using System.IO;
using System;

public class AgentController : MonoBehaviour
{
    public int waterGathered;
    public int foodGathered;

    public int waterUsed;
    public int foodUsed;

    public int startWater;
    public int startFood;

    [Min(2)]
    public int numberOfAgents = 2;
    public int numberOfCycles;

    public float startPercentage;

    private int _cyclesPassed = 0;

    private Agent[] _agents;
    private Agent _bestAgent;
    private Agent _secondBestAgent;

    //creates the correct amount of agents
    private void Start()
    {
        HandleData();
        CreateNewCycle(false);
        TestGeneration();
    }

    //create new agents
    private void CreateNewCycle(bool _firstCycle)
    {
        switch (_firstCycle)
        {
            case false:
                _agents = new Agent[numberOfAgents];

                for (int i = 0; i < _agents.Count(); i++)
                {
                    _agents[i] = new Agent(this);
                }

                break;

            case true:
                for (int i = 0; i < _agents.Count(); i++)
                {
                    if (i < _agents.Count() / 2)
                    {
                        _agents[i] = new Agent(this, _bestAgent);
                    }
                    else
                    {
                        _agents[i] = new Agent(this, _secondBestAgent);
                    }
                }

                ResetBestAgents();

                break;
        }
    }

    private void ResetBestAgents()
    {
        _bestAgent = null;
        _secondBestAgent = null;
    }


    private void TestGeneration()
    {
        if(_cyclesPassed < numberOfCycles)
        {
            StartAgents();      
            foreach (Agent _agent in _agents)
            {
                TestIfAgentIsBest(_agent);
            }          
            HandleData();
            CreateNewCycle(true);
            _cyclesPassed += 1;
            TestGeneration();
        }
    }

    private void StartAgents()
    {
        foreach (Agent agent in _agents)
        {
            agent.StartNewDay();
        }
    }

    private void TestIfAgentIsBest(Agent _agent)
    {
        try
        {
            if ((_bestAgent != null) && (_secondBestAgent != null))
            {
                if (_agent.lifeTime > _secondBestAgent.lifeTime)
                {
                    if (_agent.lifeTime > _bestAgent.lifeTime)
                    {
                        _secondBestAgent = _bestAgent;
                        _bestAgent = _agent;
                    }
                    else
                    {
                        _secondBestAgent = _agent;
                    }
                }
            }
            else
            {
                _bestAgent = _agent;
                _secondBestAgent = _agent;
            }
        }
        catch(NullReferenceException e)
        {
            if(e.Source != null)
            {
                Debug.Log("NullRefrenceException: " + e.Message + " " + e.Source);
            }
        }
    }

    //writes a console message with the best lifetiem and the corresponding waterGatherPercentage
    //After that it writes the data to a .txt file
    private void HandleData()
    {
        try
        {
            Debug.Log(_bestAgent);
            string informationalMessage = "lifetime " + _bestAgent.lifeTime + " waterpercentage: " + _bestAgent.waterGatherPercentage;
            Debug.Log(informationalMessage);

            File.AppendAllText("data.txt", _bestAgent.waterGatherPercentage.ToString() + "\n");
            File.AppendAllText("data2.txt", _bestAgent.lifeTime.ToString() + "\n");
        }
        catch(NullReferenceException e)
        {
            Debug.Log("Failed to handle data, NullRefrenceException:" + e.Message + " " + e.Source);
        }
        
    }

    private void Update()
    {
        if(Input.GetKeyDown(KeyCode.E))
        {
            numberOfCycles += 200;
            TestGeneration();
        }
    }
}
